// Copyright (c) 2026, Sione Hikaione Fonua Kata and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Ngaue Tanaki", {
// 	refresh(frm) {

// 	},
// });
