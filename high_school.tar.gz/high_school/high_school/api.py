import json
from urllib.parse import unquote

import frappe
from frappe import _
from frappe.utils import getdate

from high_school.high_school.attendance_utils import (
    mark_standard_attendance,
    mark_taliui_attendance_records,
)
from high_school.high_school.fee_utils import generate_custom_fees


# ---------------------------------------------------------------------------
# TALIUI / BOARDING ATTENDANCE
# ---------------------------------------------------------------------------

@frappe.whitelist()
def get_taliui_records(house, date, taliui):
    """Return students in a house with their attendance status for a Taliui shift."""

    students = frappe.get_all(
        "Student",
        fields=["name as student", "student_name"],
        filters={
            "custom_falemohe": house,
            "enabled": 1,
        },
        order_by="student_name",
    )

    existing_attendance = frappe.get_all(
        "Taliui Akonofo",
        filters={
            "house": house,
            "date": date,
            "taliui": taliui,
        },
        fields=["student", "status"],
    )

    attendance_by_student = {
        row.student: row.status for row in existing_attendance
    }

    for student in students:
        # Default status
        student.status = attendance_by_student.get(student.student, "Absent")

        # Approved leave overrides attendance
        on_leave = frappe.db.exists(
            "Student Leave Application",
            {
                "student": student.student,
                "start_date": ["<=", date],
                "end_date": [">=", date],
                "docstatus": 1,
            },
        )

        if on_leave:
            student.status = "Leave"

    return students


@frappe.whitelist()
def mark_taliui_attendance(
    students_present,
    students_absent,
    house,
    taliui,
    date,
):
    """Create or update Taliui attendance records."""

    present = json.loads(students_present)
    absent = json.loads(students_absent)

    mark_taliui_attendance_records(
        present + absent,
        house=house,
        taliui=taliui,
        date=date,
    )

    return True


# ---------------------------------------------------------------------------
# STUDENT GROUP / OPTION GROUP
# ---------------------------------------------------------------------------

@frappe.whitelist()
def get_students_custom(*args, **kwargs):
    """
    Return students for either:

    1. Custom High School option groups (Opt1-Opt4)
    2. Standard Frappe Education student groups
    """

    request_data = frappe._dict(
        kwargs if kwargs else frappe.local.form_dict
    )

    identifier = (
        request_data.get("student_group")
        or request_data.get("student_group_name")
    )

    if not identifier:
        referrer = frappe.local.request.referrer or ""

        if "student-group/" in referrer:
            identifier = (
                referrer
                .split("student-group/")[-1]
                .split("?")[0]
            )

    if not identifier:
        frappe.throw(_("Student Group is required."))

    identifier = unquote(str(identifier))

    option_field_map = {
        "Opt1": "custom_option_1",
        "Opt2": "custom_option_2",
        "Opt3": "custom_option_3",
        "Opt4": "custom_option_4",
    }

    option_field_name = next(
        (
            field_name
            for option_name, field_name in option_field_map.items()
            if option_name in identifier
        ),
        None,
    )

    # -----------------------------------------------------------------------
    # CUSTOM OPTION GROUP
    # -----------------------------------------------------------------------

    if option_field_name:
        student = frappe.qb.DocType("Student")
        program_enrollment = frappe.qb.DocType("Program Enrollment")

        option_field = getattr(student, option_field_name)

        query = (
            frappe.qb.from_(program_enrollment)
            .join(student)
            .on(program_enrollment.student == student.name)
            .select(
                program_enrollment.student,
                program_enrollment.student_name,
            )
            .where(
                program_enrollment.academic_year
                == request_data.get("academic_year")
            )
            .where(program_enrollment.docstatus == 1)
            .where(option_field == request_data.get("course"))
        )

        if request_data.get("program"):
            query = query.where(
                program_enrollment.program
                == request_data.get("program")
            )

        if request_data.get("batch"):
            query = query.where(
                program_enrollment.student_batch_name
                == request_data.get("batch")
            )

        students = query.run(as_dict=True)

        for student_row in students:
            student_row.active = int(
                frappe.db.get_value(
                    "Student",
                    student_row.student,
                    "enabled",
                )
                or 0
            )

        return students

    # -----------------------------------------------------------------------
    # STANDARD FRAPPE EDUCATION GROUP
    # -----------------------------------------------------------------------

    from education.education.doctype.student_group.student_group import (
        get_students,
    )

    return get_students(
        academic_year=request_data.get("academic_year"),
        group_based_on=request_data.get("group_based_on"),
        academic_term=request_data.get("academic_term"),
        program=request_data.get("program"),
        batch=request_data.get("batch"),
        student_category=request_data.get("student_category"),
        course=request_data.get("course"),
    )


# ---------------------------------------------------------------------------
# STANDARD ATTENDANCE API
# ---------------------------------------------------------------------------

@frappe.whitelist()
def custom_mark_attendance(
    students_present,
    students_absent,
    course_schedule=None,
    student_group=None,
    date=None,
):
    """Mark standard Student Attendance using High School rules."""

    present = json.loads(students_present)
    absent = json.loads(students_absent)

    for student in present:
        mark_standard_attendance(
            student=student["student"],
            student_name=student["student_name"],
            status="Present",
            course_schedule=course_schedule,
            student_group=student_group,
            date=date,
        )

    for student in absent:
        mark_standard_attendance(
            student=student["student"],
            student_name=student["student_name"],
            status="Absent",
            course_schedule=course_schedule,
            student_group=student_group,
            date=date,
        )

    frappe.db.commit()

    frappe.msgprint(
        _("Attendance has been marked successfully.")
    )

    return True


# ---------------------------------------------------------------------------
# FEE API
# ---------------------------------------------------------------------------

@frappe.whitelist()
def create_student_fees(student_enrollment):
    """
    Public API wrapper for custom fee generation.

    The actual fee logic lives in fee_utils.py.
    """

    doc = frappe.get_doc(
        "Program Enrollment",
        student_enrollment,
    )

    return generate_custom_fees(doc)
